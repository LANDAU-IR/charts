{{/*
Expand the name of the chart.
*/}}
{{- define "lnd.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "lnd.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "lnd.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "lnd.labels" -}}
helm.sh/chart: {{ include "lnd.chart" . }}
{{ include "lnd.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "lnd.selectorLabels" -}}
app.kubernetes.io/name: {{ include "lnd.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "lnd.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "lnd.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the configuration variables
*/}}
{{- define "lnd.global.configuration" -}}
{{- range $service, $config := .Values.global.configuration }}
- name: {{ $service | upper }}_HOST
  value: {{ $config.host | quote }}
- name: {{ $service | upper }}_API_PORT
  value: {{ $config.api | default "80" | quote }}
{{- end }}
{{- end }}

{{/*
Create the secrets variable
*/}}
{{- define "lnd.global.secrets" -}}
# **********************
# Application Secrets
# **********************
- name: AES_KEY
  valueFrom:
    secretKeyRef:
      name: lnd-secrets
      key: AES_KEY
# **********************
# Captcha Services
# **********************
# Altcha
- name: ALTCHA_HMAC_KEY
  valueFrom:
    secretKeyRef:
      name: lnd-secrets
      key: HMAC_KEY
# **********************
# PSP (payment provider)
# **********************
- name: PSP_SECRET
  valueFrom:
    secretKeyRef:
      name: lnd-secrets
      key: PSP_SECRET
{{- with .Values.global.secrets.vapid }}
{{- if .privateKey }}
# **********************
# Push Information
# **********************
# VAPID
- name: VAPID_PRIVATE_KEY
  valueFrom:
    secretKeyRef:
      name: lnd-secrets
      key: VAPID_PRIVATE_KEY
{{- end }}
{{- end }}
{{- with .Values.global.secrets.init }}
{{- if .adminPassword }}
# **********************
# Seed Credentials
# **********************
- name: INIT_LND_ADMIN_PASSWORD
  valueFrom:
    secretKeyRef:
      name: lnd-secrets
      key: INIT_LND_ADMIN_PASSWORD
{{- end }}
{{- end }}
{{- end }}

{{/*
One key of lnd-secrets, base64-encoded: the operator's value, else the value the cluster already
holds, else a fresh mint. `randAlphaNum` runs on every render, so without the middle step every
`helm upgrade` that left a value unset re-minted the key — a re-minted AES_KEY makes everything
encrypted under the old one unreadable and a re-minted PSP_SECRET fails every callback still in
flight, with the upgrade reporting success. A key the stored Secret lacks is minted once, not
refused: an install older than 1.0.5 has no PSP_SECRET, and refusing would block its upgrade.
Takes a dict: `key`, `value`, and `prior` (the stored Secret's `.data`, or an empty dict).
*/}}
{{- define "lnd.secrets.resolve" -}}
{{- $v := .value | default "" | toString }}
{{- if $v }}
{{- $v | b64enc }}
{{- else if index .prior .key }}
{{- index .prior .key }}
{{- else }}
{{- randAlphaNum 16 | sha256sum | trunc 64 | b64enc }}
{{- end }}
{{- end }}

{{/*
Create the environments variable
*/}}
{{- define "lnd.global.environments" -}}
- name: APP_VERSION
  value: {{ .Values.global.image.tag | quote }}
# **********************
# Global Configuration
# **********************
- name: NODE_ENV
  value: {{ .Values.global.environments.nodeEnv | default "develop" | quote }}
- name: DEBUG
  value: {{ .Values.global.environments.debug | default "clt:*" | quote }}
- name: TIMEOUT
  value: {{ .Values.global.environments.timeout | default "90000" | quote }}
{{- if not (kindIs "invalid" .Values.global.environments.graphqlMutationSupport) }}
- name: GRAPHQL_MUTATION_SUPPORT
  value: {{ .Values.global.environments.graphqlMutationSupport | quote }}
{{- end }}
# **********************
# Internationalization
# **********************
- name: LOCALE
  value: {{ .Values.global.environments.locale | default "fa" | quote }}
- name: REGION
  value: {{ .Values.global.environments.region | default "IR" | quote }}
- name: TZ
  value: {{ .Values.global.environments.tz | default "Asia/Tehran" | quote }}
# *****************************
# Messaging Config
# *****************************
# Kavenegar
- name: KAVENEGAR_SENDERS
  value: {{ .Values.global.environments.kavenegar.senders | quote }}
- name: KAVENEGAR_API_KEY
  value: {{ .Values.global.environments.kavenegar.apiKey | quote }}
# Melipayamak
- name: MELIPAYAMAK_USER
  value: {{ .Values.global.environments.melipayamak.user | quote }}
- name: MELIPAYAMAK_PASS
  value: {{ .Values.global.environments.melipayamak.pass | quote }}
- name: MELIPAYAMAK_FROM
  value: {{ .Values.global.environments.melipayamak.from | quote }}
{{- if .Values.global.environments.zarinpal }}
# **********************
# IPG Config
# **********************
- name: ZARINPAL_URL
  value: {{ .Values.global.environments.zarinpal.url | quote }}
- name: ZARINPAL_MERCHANT_ID
  value: {{ .Values.global.environments.zarinpal.merchantId | quote }}
- name: ZARINPAL_CALLBACK_URL
  value: {{ .Values.global.environments.zarinpal.callbackUrl | quote }}
- name: ZARINPAL_REDIRECT_URL
  value: {{ .Values.global.environments.zarinpal.redirectUrl | quote }}
- name: ZARINPAL_TIMEOUT_MS
  value: {{ .Values.global.environments.zarinpal.timeoutMs | default "20000" | quote }}
{{- end }}
{{- if .Values.global.environments.zibal }}
# Zibal, the provider since decision 194; the live merchant belongs in a production release's own values
- name: ZIBAL_URL
  value: {{ .Values.global.environments.zibal.url | quote }}
- name: ZIBAL_MERCHANT
  value: {{ .Values.global.environments.zibal.merchant | quote }}
- name: ZIBAL_REDIRECT_URL
  value: {{ .Values.global.environments.zibal.redirectUrl | quote }}
- name: ZIBAL_TIMEOUT_MS
  value: {{ .Values.global.environments.zibal.timeoutMs | default "20000" | quote }}
{{- end }}
{{- if .Values.global.environments.psp }}
# **********************
# PSP (payment provider)
# **********************
- name: PSP_PROVIDER
  value: {{ .Values.global.environments.psp.provider | default "zibal" | quote }}
{{- if not (kindIs "invalid" .Values.global.environments.psp.allowFake) }}
- name: PSP_ALLOW_FAKE
  value: {{ .Values.global.environments.psp.allowFake | quote }}
{{- end }}
{{- with .Values.global.environments.psp.merchantId }}
- name: PSP_MERCHANT_ID
  value: {{ . | quote }}
{{- end }}
- name: PSP_CALLBACK_URL
  value: {{ .Values.global.environments.psp.callbackUrl | quote }}
- name: PSP_TIMEOUT_SECONDS
  value: {{ .Values.global.environments.psp.timeoutSeconds | default "900" | quote }}
{{- end }}
# **********************
# Landau Config
# **********************
{{- if .Values.global.environments.landau }}
# env-gate: unread — no reader in any Landau repo; left in place pending a deliberate removal
- name: LANDAU_USER_ID
  value: {{ .Values.global.environments.landau.userId | quote }}
{{- end }}
{{- if .Values.global.environments.order }}
# **********************
# Order Config
# **********************
- name: ORDER_AUTO_REJECT_HOURS
  value: {{ .Values.global.environments.order.autoRejectHours | default "48" | quote }}
- name: ORDER_DISPUTE_WINDOW_DAYS
  value: {{ .Values.global.environments.order.disputeWindowDays | default "7" | quote }}
# Decision 172: `0` is a setting (disputable at once), so the value renders bare and takes its default from values.yaml;
# a key an operator deletes emits nothing and the app's own 72 applies.
{{- if not (kindIs "invalid" .Values.global.environments.order.selfTransportDisputeHours) }}
- name: ORDER_SELF_TRANSPORT_DISPUTE_HOURS
  value: {{ .Values.global.environments.order.selfTransportDisputeHours | quote }}
{{- end }}
# Plan 118 (LND-222): a money transition's claim goes stale after this many seconds. `0` is not a setting the app
# accepts (it falls back to 120), so `default` is safe here.
- name: ORDER_TRANSITION_CLAIM_STALE_SECONDS
  value: {{ .Values.global.environments.order.transitionClaimStaleSeconds | default "120" | quote }}
{{- if not (kindIs "invalid" .Values.global.environments.order.selfSupplyAutoConfirm) }}
- name: ORDER_SELF_SUPPLY_AUTO_CONFIRM
  value: {{ .Values.global.environments.order.selfSupplyAutoConfirm | quote }}
{{- end }}
# Must agree with the frontend's NUXT_PUBLIC_POS_ENABLED, or a button is offered and refused.
{{- if not (kindIs "invalid" .Values.global.environments.order.posEnabled) }}
- name: ORDER_POS_ENABLED
  value: {{ .Values.global.environments.order.posEnabled | quote }}
{{- end }}
# The POS numbers and flags below render bare, like STRICT_TOKEN: `0` is a meaningful setting for
# each number ("disabled", by the backend's own rule) and `| default` fires on `0` exactly as it
# fires on `false`, handing the shipped value back to an operator who turned the control off. Their
# defaults live in values.yaml. The `kindIs "invalid"` guards cover the other trap: a key set to
# `null` is deleted by Helm's merge and a bare render of it is `""`, which the app reads as `0` (or
# `false`) — the guard emits nothing instead. How far the deletion reaches is Helm's, not ours: it
# holds in the gateway's own render, but a subchart's `global` is refilled from this chart's
# values.yaml, and with any subchart enabled a *nested* nulled key (`order.*`, `psp.*`) comes back in
# the gateway too — so those pods get the chart default. Never `""`, which is the trap the guard is for.
{{- with .Values.global.environments.order }}
{{- if not (kindIs "invalid" .posUnreconciledCeiling) }}
- name: ORDER_POS_UNRECONCILED_CEILING
  value: {{ .posUnreconciledCeiling | quote }}
{{- end }}
{{- if not (kindIs "invalid" .posAutoReconcile) }}
- name: ORDER_POS_AUTO_RECONCILE
  value: {{ .posAutoReconcile | quote }}
{{- end }}
{{- if not (kindIs "invalid" .posManualAbove) }}
- name: ORDER_POS_MANUAL_ABOVE
  value: {{ .posManualAbove | quote }}
{{- end }}
{{- if not (kindIs "invalid" .posProbationSettles) }}
- name: ORDER_POS_PROBATION_SETTLES
  value: {{ .posProbationSettles | quote }}
{{- end }}
{{- if not (kindIs "invalid" .posProbationDays) }}
- name: ORDER_POS_PROBATION_DAYS
  value: {{ .posProbationDays | quote }}
{{- end }}
{{- if not (kindIs "invalid" .posVelocityMax) }}
- name: ORDER_POS_VELOCITY_MAX
  value: {{ .posVelocityMax | quote }}
{{- end }}
{{- if not (kindIs "invalid" .posVelocityWindowMinutes) }}
- name: ORDER_POS_VELOCITY_WINDOW_MINUTES
  value: {{ .posVelocityWindowMinutes | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- if .Values.global.environments.dispatch }}
# **********************
# Dispatch Config
# **********************
- name: DISPATCH_RADIUS_KM
  value: {{ .Values.global.environments.dispatch.radiusKm | default "50" | quote }}
- name: DISPATCH_DETOUR_FACTOR
  value: {{ .Values.global.environments.dispatch.detourFactor | default "1.4" | quote }}
- name: DISPATCH_WAVE_MINUTES
  value: {{ .Values.global.environments.dispatch.waveMinutes | quote }}
- name: DISPATCH_POSITION_TTL_MINUTES
  value: {{ .Values.global.environments.dispatch.positionTtlMinutes | default "30" | quote }}
- name: DISPATCH_ROUTING_COSTING
  value: {{ .Values.global.environments.dispatch.routingCosting | default "auto" | quote }}
- name: DISPATCH_ROUTING_POOL
  value: {{ .Values.global.environments.dispatch.routingPool | default "24" | quote }}
{{- with .Values.global.environments.dispatch.default }}
- name: DISPATCH_DEFAULT_WEIGHT_KG
  value: {{ .weightKg | default "5" | quote }}
- name: DISPATCH_DEFAULT_WIDTH_CM
  value: {{ .widthCm | default "30" | quote }}
- name: DISPATCH_DEFAULT_HEIGHT_CM
  value: {{ .heightCm | default "30" | quote }}
- name: DISPATCH_DEFAULT_LENGTH_CM
  value: {{ .lengthCm | default "30" | quote }}
{{- end }}
# Bare, guarded — see the Order block for why.
{{- if not (kindIs "invalid" .Values.global.environments.dispatch.requireGuarantee) }}
- name: DISPATCH_REQUIRE_GUARANTEE
  value: {{ .Values.global.environments.dispatch.requireGuarantee | quote }}
{{- end }}
{{- end }}
{{- if .Values.global.environments.operations }}
# **********************
# Operations Config
# **********************
- name: OPERATIONS_TICK_SECONDS
  value: {{ .Values.global.environments.operations.tickSeconds | default "60" | quote }}
- name: OPERATIONS_LOCK_SECONDS
  value: {{ .Values.global.environments.operations.lockSeconds | default "300" | quote }}
{{- end }}
{{- if .Values.global.environments.wholesale }}
# **********************
# Wholesale Config
# **********************
- name: RESTOCK_TERMS_DAYS
  value: {{ .Values.global.environments.wholesale.restockTermsDays | default "30" | quote }}
# Bare, guarded — see the Order block for why. `0` escrow days makes every hold fall due at once.
{{- with .Values.global.environments.wholesale }}
{{- if not (kindIs "invalid" .restockEscrowDays) }}
- name: RESTOCK_ESCROW_DAYS
  value: {{ .restockEscrowDays | quote }}
{{- end }}
{{- if not (kindIs "invalid" .restockPosEnabled) }}
- name: RESTOCK_POS_ENABLED
  value: {{ .restockPosEnabled | quote }}
{{- end }}
{{- if not (kindIs "invalid" .restockPosManualAbove) }}
- name: RESTOCK_POS_MANUAL_ABOVE
  value: {{ .restockPosManualAbove | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- if .Values.global.environments.market }}
# **********************
# Market Config
# **********************
# Bare, guarded — see the Order block for why.
{{- if not (kindIs "invalid" .Values.global.environments.market.sellerFloor) }}
- name: MARKET_SELLER_FLOOR
  value: {{ .Values.global.environments.market.sellerFloor | quote }}
{{- end }}
{{- end }}
{{- if .Values.global.environments.mirror }}
# **********************
# Mirror Config
# **********************
# The CDC mirror's own bookkeeping (backend plan 105). Bare, guarded — see the Order block for why.
{{- if not (kindIs "invalid" .Values.global.environments.mirror.maxAttempts) }}
- name: CQRS_MAX_ATTEMPTS
  value: {{ .Values.global.environments.mirror.maxAttempts | quote }}
{{- end }}
{{- if not (kindIs "invalid" .Values.global.environments.mirror.lagThresholdMs) }}
- name: CQRS_LAG_THRESHOLD_MS
  value: {{ .Values.global.environments.mirror.lagThresholdMs | quote }}
{{- end }}
{{- end }}
# *****************************
# Client Config
# *****************************
# No `| default`: Helm's default fires on `false` too, so a deployment that turned this off got
# `"true"` back. The chart's own values.yaml carries the `true`.
{{- if not (kindIs "invalid" .Values.global.environments.strictToken) }}
- name: STRICT_TOKEN
  value: {{ .Values.global.environments.strictToken | quote }}
{{- end }}
- name: UID
  value: {{ .Values.global.environments.uid | quote }}
- name: CID
  value: {{ .Values.global.environments.cid | quote }}
- name: APP_ID
  value: {{ .Values.global.environments.appId | quote }}
- name: CLIENT_ID
  value: {{ .Values.global.environments.clientId | quote }}
- name: CLIENT_SECRET
  value: {{ .Values.global.environments.clientSecret | quote }}
- name: ROOT_DOMAIN
  value: {{ .Values.global.environments.root.domain | default "lnd.landau.app" | quote }}
- name: ROOT_SUBJECT
  value: {{ .Values.global.environments.root.subject | default "root@lnd.landau.app" | quote }}
- name: PLATFORM_URL
  value: {{ .Values.global.environments.platformUrl | default "http://platform-gateway.wenex-platform.svc.cluster.local" | quote }}
# Backend
- name: CLIENT_AUTHORIZATION_CQRS
  value: {{ .Values.global.environments.backend.authorizationCqrs | quote }}
- name: API_KEY
  value: {{ .Values.global.environments.apiKey | quote }}
# Frontend
- name: CLIENT_BASE_URL
  value: {{ .Values.global.environments.frontend.baseUrl | default "https://lnd.landau.app" | quote }}
- name: CLIENT_ASSETS_URL
  value: {{ .Values.global.environments.frontend.assetsUrl | default "https://assets.lnd.landau.app" | quote }}
{{- with .Values.global.environments.altcha }}
# **********************
# Captcha Services
# **********************
# Altcha (its HMAC key comes from the secret above)
- name: ALTCHA_MAX_NUMBER
  value: {{ .maxNumber | default "100000" | quote }}
{{- end }}
{{- with .Values.global.environments.throttle }}
# **********************
# Public Route Rate Limit
# **********************
# Plan 123.1: every route that needs no session is limited per client address, per gateway replica. `0` is not a
# setting the app accepts (it keeps its default), so `default` is safe; `int64` keeps a large window out of `1e+06`.
- name: PUBLIC_RATE_TTL_MS
  value: {{ .ttlMs | default "60000" | int64 | quote }}
- name: PUBLIC_RATE_LIMIT
  value: {{ .limit | default "120" | int64 | quote }}
- name: PUBLIC_CONTACT_RATE_LIMIT
  value: {{ .contactLimit | default "5" | int64 | quote }}
# How many proxies append to X-Forwarded-For in front of the gateway. `0` is a setting (nothing in front: key on the
# socket), so it renders bare and takes its default from values.yaml; a deleted key emits nothing and the app's 1 applies.
{{- if not (kindIs "invalid" .proxyHops) }}
- name: PUBLIC_RATE_PROXY_HOPS
  value: {{ .proxyHops | int64 | quote }}
{{- end }}
{{- end }}
{{- with .Values.global.environments.publicOffers }}
# **********************
# Public Catalogue
# **********************
# Plan 124.1: seconds one process keeps the 30-day sales count the landing row's best-selling order reads. `0` is not a
# setting the app accepts (it keeps its default), so `default` is safe.
- name: PUBLIC_OFFERS_SALES_TTL_SECONDS
  value: {{ .salesTtlSeconds | default "300" | int64 | quote }}
{{- end }}
{{- with .Values.global.environments.vapid }}
{{- with .publicKey }}
# **********************
# Push Information
# **********************
# VAPID (its private key comes from the secret above)
- name: VAPID_PUBLIC_KEY
  value: {{ . | quote }}
{{- end }}
{{- end }}
{{- with .Values.global.environments.mail }}
# **********************
# Mail Identities
# **********************
{{- with .noReply }}
- name: NO_REPLY_MAIL
  value: {{ . | quote }}
{{- end }}
{{- with .support }}
- name: SUPPORT_MAIL
  value: {{ . | quote }}
{{- end }}
{{- end }}
# **********************
# Logging Services
# **********************
# Sentry
- name: SENTRY_DSN
  value: {{ .Values.global.environments.sentry.dsn | quote }}
- name: SENTRY_MAX_BREADCRUMBS
  value: {{ .Values.global.environments.sentry.maxBreadcrumbs | default "100" | quote }}
- name: SENTRY_TRACES_SAMPLE_RATE
  value: {{ .Values.global.environments.sentry.tracesSampleRate | default "0.8" | quote }}
# **********************
# Storage Services
# **********************
# Redis
- name: REDIS_HOST
  value: {{ .Values.global.environments.redis.host | quote }}
- name: REDIS_PORT
  value: {{ .Values.global.environments.redis.port | default "6379" | quote }}
- name: REDIS_PREFIX
  value: {{ .Values.global.environments.redis.prefix | default "lnd" | quote }}
- name: REDIS_PASSWORD
  value: {{ .Values.global.environments.redis.password | quote }}
# Mongo
- name: MONGO_HOST
  value: {{ .Values.global.environments.mongo.host | quote }}
- name: MONGO_DB
  value: {{ .Values.global.environments.mongo.db | default "landau" | quote }}
- name: MONGO_PREFIX
  value: {{ .Values.global.environments.mongo.prefix | default "lnd" | quote }}
- name: MONGO_USER
  value: {{ .Values.global.environments.mongo.user | quote }}
- name: MONGO_PASS
  value: {{ .Values.global.environments.mongo.pass | quote }}
- name: MONGO_QUERY
  value: {{ .Values.global.environments.mongo.query | default "replicaSet=rs0&authSource=admin" | quote }}
# **********************
# Broker Services
# **********************
# Nats
- name: NATS_USER
  value: {{ .Values.global.environments.nats.user | default "lnd" | quote }}
- name: NATS_PASS
  value: {{ .Values.global.environments.nats.pass | default "lnd" | quote }}
- name: NATS_TIMEOUT
  value: {{ .Values.global.environments.nats.timeout | default "90000" | quote }}
- name: NATS_SERVERS
  value: {{ .Values.global.environments.nats.servers | default "nats://nats.nats.svc.cluster.local:4222" | quote }}
# *****************************
# OAuth Information
# *****************************
# Google
- name: GOOGLE_CLIENT_ID
  value: {{ .Values.global.environments.google.client.id | quote }}
- name: GOOGLE_CLIENT_SECRET
  value: {{ .Values.global.environments.google.client.secret | quote }}
- name: GOOGLE_REDIRECT_URI
  value: {{ .Values.global.environments.google.client.redirectUri | default "https://lnd.landau.app/oauth" | quote }}
# **********************
# Telemetry Services
# **********************
# OpenTelemetry
- name: OTLP_PORT
  value: {{ .Values.global.environments.otlp.port | default "4318" | quote }}
- name: OTLP_HOST
  value: {{ .Values.global.environments.otlp.host | default "jaeger-instance-collector.opentelemetry.svc.cluster.local" | quote }}
# **********************
# APM Service
# **********************
# Elastic APM
- name: ELASTIC_APM_SERVER_URL
  value: {{ .Values.global.environments.apm.serverUrl | quote }}
- name: ELASTIC_APM_SECRET_TOKEN
  value: {{ .Values.global.environments.apm.secretToken | quote }}
- name: ELASTIC_APM_VERIFY_SERVER_CERT
  value: {{ .Values.global.environments.apm.verifyServerCert | default "false" | quote }}
# **********************
# Wenex Coworkers
# **********************
- name: COWORKERS
  value: {{ .Values.global.environments.coworkers | toJson | quote }}
{{- end }}
